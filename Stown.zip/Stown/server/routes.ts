import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Set up authentication routes
  setupAuth(app);

  // Subscription routes
  app.post("/api/subscriptions", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const subscription = await storage.createSubscription({
      userId: req.user!.id,
      plan: req.body.plan,
      status: "active",
      startDate: new Date(),
    });

    res.json(subscription);
  });

  app.get("/api/subscriptions/current", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const subscription = await storage.getSubscription(req.user!.id);
    if (!subscription) {
      return res.status(404).json({ message: "No active subscription found" });
    }

    res.json(subscription);
  });

  // Creator routes (require authentication)
  app.post("/api/creators", async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== "creator") {
      return res.status(403).json({ message: "Only creators can access this endpoint" });
    }

    const creator = await storage.createCreator({
      userId: req.user!.id,
      ...req.body
    });

    res.json(creator);
  });

  app.get("/api/creators", async (_req, res) => {
    const creators = await storage.getCreators();
    res.json(creators);
  });

  app.get("/api/creators/:id", async (req, res) => {
    const creator = await storage.getCreator(parseInt(req.params.id));
    if (!creator) {
      return res.status(404).json({ message: "Creator not found" });
    }
    res.json(creator);
  });

  app.get("/api/creators/:id/content", async (req, res) => {
    const content = await storage.getContentByCreator(parseInt(req.params.id));
    res.json(content);
  });

  // Content routes
  app.post("/api/content", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const creator = await storage.getCreatorByUserId(req.user!.id);
    if (!creator) {
      return res.status(403).json({ message: "Only creators can post content" });
    }

    const content = await storage.createContent({
      ...req.body,
      creatorId: creator.id
    });

    res.json(content);
  });

  app.get("/api/content", async (_req, res) => {
    const content = await storage.getAllContent();
    res.json(content);
  });

  app.get("/api/content/featured", async (_req, res) => {
    const featured = await storage.getFeaturedContent();
    res.json(featured);
  });

  app.get("/api/content/:id", async (req, res) => {
    const content = await storage.getContent(parseInt(req.params.id));
    if (!content) {
      return res.status(404).json({ message: "Content not found" });
    }
    res.json(content);
  });

  app.get("/api/search", async (req, res) => {
    const query = req.query.q as string;
    if (!query) {
      return res.status(400).json({ message: "Search query required" });
    }
    const results = await storage.searchContent(query);
    res.json(results);
  });

  return httpServer;
}