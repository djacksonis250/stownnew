import { 
  Content, Creator, InsertContent, InsertCreator,
  User, InsertUser, Subscription, InsertSubscription,
  users, creators, content, subscriptions
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ilike } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Subscription operations
  getSubscription(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, subscription: Partial<InsertSubscription>): Promise<Subscription>;

  // Creator operations
  getCreator(id: number): Promise<Creator | undefined>;
  getCreators(): Promise<Creator[]>;
  createCreator(creator: InsertCreator): Promise<Creator>;
  getCreatorByUserId(userId: number): Promise<Creator | undefined>;

  // Content operations  
  getContent(id: number): Promise<Content | undefined>;
  getAllContent(): Promise<Content[]>;
  getContentByCreator(creatorId: number): Promise<Content[]>;
  getFeaturedContent(): Promise<Content[]>;
  createContent(content: InsertContent): Promise<Content>;
  searchContent(query: string): Promise<Content[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Subscription operations
  async getSubscription(userId: number): Promise<Subscription | undefined> {
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId));
    return subscription;
  }

  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const [newSubscription] = await db
      .insert(subscriptions)
      .values(subscription)
      .returning();
    return newSubscription;
  }

  async updateSubscription(
    id: number,
    subscription: Partial<InsertSubscription>
  ): Promise<Subscription> {
    const [updatedSubscription] = await db
      .update(subscriptions)
      .set(subscription)
      .where(eq(subscriptions.id, id))
      .returning();
    return updatedSubscription;
  }

  // Creator operations
  async getCreator(id: number): Promise<Creator | undefined> {
    const [creator] = await db.select().from(creators).where(eq(creators.id, id));
    return creator;
  }

  async getCreators(): Promise<Creator[]> {
    return db.select().from(creators);
  }

  async createCreator(creator: InsertCreator): Promise<Creator> {
    const [newCreator] = await db.insert(creators).values(creator).returning();
    return newCreator;
  }

  async getCreatorByUserId(userId: number): Promise<Creator | undefined> {
    const [creator] = await db.select().from(creators).where(eq(creators.userId, userId));
    return creator;
  }

  // Content operations
  async getContent(id: number): Promise<Content | undefined> {
    const [content] = await db.select().from(content).where(eq(content.id, id));
    return content;
  }

  async getAllContent(): Promise<Content[]> {
    return db.select().from(content);
  }

  async getContentByCreator(creatorId: number): Promise<Content[]> {
    return db.select().from(content).where(eq(content.creatorId, creatorId));
  }

  async getFeaturedContent(): Promise<Content[]> {
    return db.select().from(content).where(eq(content.featured, true));
  }

  async createContent(contentData: InsertContent): Promise<Content> {
    const [newContent] = await db.insert(content).values(contentData).returning();
    return newContent;
  }

  async searchContent(query: string): Promise<Content[]> {
    const searchTerm = `%${query.toLowerCase()}%`;
    return db
      .select()
      .from(content)
      .where(
        or(
          ilike(content.title, searchTerm),
          ilike(content.description, searchTerm)
        )
      );
  }
}

export const storage = new DatabaseStorage();