import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import ContentGrid from "@/components/content/content-grid";
import { Skeleton } from "@/components/ui/skeleton";
import type { Creator, Content } from "@shared/schema";

export default function CreatorPage() {
  const { id } = useParams<{ id: string }>();

  const { data: creator, isLoading: creatorLoading } = useQuery<Creator>({
    queryKey: [`/api/creators/${id}`],
  });

  const { data: creatorContent, isLoading: contentLoading } = useQuery<Content[]>({
    queryKey: [`/api/creators/${id}/content`],
  });

  if (creatorLoading || contentLoading) {
    return <Skeleton className="w-full h-[400px]" />;
  }

  if (!creator) return <div>Creator not found</div>;

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-6">
        <Avatar className="h-32 w-32">
          <AvatarImage src={creator.imageUrl} alt={creator.name} />
          <AvatarFallback>{creator.name[0]}</AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-4xl font-bold">{creator.name}</h1>
          <p className="text-lg text-muted-foreground mt-2">{creator.bio}</p>
        </div>
      </div>
      <ContentGrid content={creatorContent || []} />
    </div>
  );
}
