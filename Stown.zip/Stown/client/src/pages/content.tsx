import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import MediaPlayer from "@/components/content/media-player";
import { Skeleton } from "@/components/ui/skeleton";
import type { Content, Creator } from "@shared/schema";

export default function ContentPage() {
  const { id } = useParams<{ id: string }>();

  const { data: content, isLoading: contentLoading } = useQuery<Content>({
    queryKey: [`/api/content/${id}`],
  });

  const { data: creator, isLoading: creatorLoading } = useQuery<Creator>({
    queryKey: [`/api/creators/${content?.creatorId}`],
    enabled: !!content,
  });

  if (contentLoading || creatorLoading) {
    return <Skeleton className="w-full h-[400px]" />;
  }

  if (!content || !creator) return <div>Content not found</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <MediaPlayer content={content} />
      <div>
        <h1 className="text-3xl font-bold">{content.title}</h1>
        <p className="text-muted-foreground mt-2">{content.description}</p>
      </div>
      <div className="border-t pt-4">
        <h2 className="font-semibold">Creator</h2>
        <p className="mt-2">{creator.name}</p>
      </div>
    </div>
  );
}
