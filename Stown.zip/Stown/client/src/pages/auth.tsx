import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { type InsertUser, insertUserSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import CreatorRegistration from "@/components/auth/creator-registration";

export default function Auth() {
  const [, setLocation] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isCreatorForm, setIsCreatorForm] = useState(false);

  const loginForm = useForm({
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      email: "",
      password: "",
      name: "",
      role: "user",
    } as InsertUser,
  });

  const handleRoleChange = (role: string) => {
    registerForm.setValue("role", role);
    setIsCreatorForm(role === "creator");
  };

  if (isCreatorForm) {
    return (
      <CreatorRegistration
        defaultValues={registerForm.getValues()}
        onBack={() => setIsCreatorForm(false)}
        onComplete={(creatorData) => {
          // Register user with creator data
          registerMutation.mutate({
            ...registerForm.getValues(),
            ...creatorData,
          });
        }}
      />
    );
  }

  return (
    <div className="min-h-[80vh] flex">
      <div className="flex-1 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold mb-2">Welcome to Stown</h2>
              <p className="text-muted-foreground">Sign in or create an account to continue</p>
            </div>
            <Tabs defaultValue="login">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <Form {...loginForm}>
                  <form
                    onSubmit={loginForm.handleSubmit((data) =>
                      loginMutation.mutate(data)
                    )}
                    className="space-y-4"
                  >
                    <FormField
                      control={loginForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={loginMutation.isPending}
                    >
                      Login
                    </Button>
                  </form>
                </Form>
              </TabsContent>

              <TabsContent value="register">
                <Form {...registerForm}>
                  <form className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Type</FormLabel>
                          <Select
                            onValueChange={handleRoleChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select account type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="user">User</SelectItem>
                              <SelectItem value="creator">Creator</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="w-full"
                      onClick={() => {
                        if (registerForm.getValues("role") === "user") {
                          registerMutation.mutate(registerForm.getValues());
                        }
                      }}
                      disabled={registerMutation.isPending}
                    >
                      Register
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <div className="hidden lg:flex flex-1 items-center justify-center bg-muted p-12">
        <div className="max-w-lg">
          <h1 className="text-4xl font-bold mb-6">Join Stown Today</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Create an account or sign in to discover amazing podcasts, music, and videos.
            Start your journey with Stown - where creators and listeners come together.
          </p>
          <div className="grid grid-cols-2 gap-6 text-sm">
            <div>
              <h2 className="font-semibold mb-2">For Users</h2>
              <ul className="space-y-2 text-muted-foreground">
                <li>✓ Access to exclusive content</li>
                <li>✓ Create personalized playlists</li>
                <li>✓ Follow your favorite creators</li>
              </ul>
            </div>
            <div>
              <h2 className="font-semibold mb-2">For Creators</h2>
              <ul className="space-y-2 text-muted-foreground">
                <li>✓ Share your content</li>
                <li>✓ Build your audience</li>
                <li>✓ Earn from subscriptions</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}