import LibraryView from "@/components/library/library-view";

export default function Home() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Your Library</h1>
      <LibraryView />
    </div>
  );
}