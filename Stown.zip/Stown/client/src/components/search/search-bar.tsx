import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import type { Content } from "@shared/schema";

export default function SearchBar() {
  const [query, setQuery] = useState("");

  const { data: results } = useQuery<Content[]>({
    queryKey: ["/api/search", query],
    enabled: query.length > 0,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search submission
  };

  return (
    <form onSubmit={handleSubmit} className="relative">
      <div className="flex gap-2">
        <Input
          type="search"
          placeholder="Search for content..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="flex-1"
        />
        <Button type="submit">
          <Search className="h-4 w-4 mr-2" />
          Search
        </Button>
      </div>
      
      {results && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-background border rounded-lg shadow-lg p-2">
          {results.map((result) => (
            <div
              key={result.id}
              className="p-2 hover:bg-accent rounded-md cursor-pointer"
            >
              {result.title}
            </div>
          ))}
        </div>
      )}
    </form>
  );
}
