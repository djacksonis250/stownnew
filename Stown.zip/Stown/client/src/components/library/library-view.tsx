import { useQuery } from "@tanstack/react-query";
import { ContentType, type Content } from "@shared/schema";
import ContentGrid from "@/components/content/content-grid";
import SearchBar from "@/components/search/search-bar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";

export default function LibraryView() {
  const { data: allContent, isLoading } = useQuery<Content[]>({
    queryKey: ["/api/content"],
  });

  if (isLoading) {
    return <Skeleton className="w-full h-[400px]" />;
  }

  const contentByType = allContent?.reduce((acc, item) => {
    if (!acc[item.type]) {
      acc[item.type] = [];
    }
    acc[item.type].push(item);
    return acc;
  }, {} as Record<ContentType, Content[]>) || {};

  return (
    <div className="space-y-8">
      <div className="max-w-2xl mx-auto">
        <SearchBar />
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="music">Music</TabsTrigger>
          <TabsTrigger value="podcast">Podcasts</TabsTrigger>
          <TabsTrigger value="video">Videos</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <ContentGrid content={allContent || []} />
        </TabsContent>
        
        {Object.entries(contentByType).map(([type, content]) => (
          <TabsContent key={type} value={type}>
            <ContentGrid content={content} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
