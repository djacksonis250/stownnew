import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Library, Search, Music, Radio, Video, UserCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function NavBar() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
            Stown
          </a>
        </Link>

        <div className="flex items-center space-x-6">
          <Button variant="ghost" size="sm" className="font-medium">
            <Library className="h-5 w-5 mr-2" />
            Library
          </Button>
          <Button variant="ghost" size="sm">
            <Music className="h-5 w-5 mr-2" />
            Music
          </Button>
          <Button variant="ghost" size="sm">
            <Radio className="h-5 w-5 mr-2" />
            Podcasts
          </Button>
          <Button variant="ghost" size="sm">
            <Video className="h-5 w-5 mr-2" />
            Videos
          </Button>
          <Button variant="ghost" size="sm">
            <Search className="h-5 w-5" />
          </Button>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <UserCircle className="h-5 w-5 mr-2" />
                  {user.name}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {user.role === "creator" && (
                  <DropdownMenuItem
                    onClick={() => setLocation(`/creator/${user.id}`)}
                  >
                    Creator Dashboard
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem
                  onClick={() => logoutMutation.mutate()}
                >
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              variant="default"
              size="sm"
              onClick={() => setLocation("/auth")}
            >
              Sign In
            </Button>
          )}
        </div>
      </div>
    </nav>
  );
}