import { Content } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Play, Pause, SkipBack, SkipForward } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface MediaPlayerProps {
  content: Content;
}

export default function MediaPlayer({ content }: MediaPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <Card className="p-6">
      <div className="aspect-video bg-muted rounded-lg mb-4">
        <img
          src={content.coverUrl}
          alt={content.title}
          className="w-full h-full object-cover rounded-lg"
        />
      </div>
      
      <div className="flex justify-center items-center gap-4">
        <Button variant="outline" size="icon">
          <SkipBack className="h-4 w-4" />
        </Button>
        <Button
          size="icon"
          onClick={() => setIsPlaying(!isPlaying)}
          className="h-12 w-12"
        >
          {isPlaying ? (
            <Pause className="h-6 w-6" />
          ) : (
            <Play className="h-6 w-6" />
          )}
        </Button>
        <Button variant="outline" size="icon">
          <SkipForward className="h-4 w-4" />
        </Button>
      </div>
    </Card>
  );
}
