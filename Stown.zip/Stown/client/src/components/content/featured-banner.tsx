import { Link } from "wouter";
import { Content } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

interface FeaturedBannerProps {
  content: Content[];
}

export default function FeaturedBanner({ content }: FeaturedBannerProps) {
  return (
    <Carousel className="w-full max-w-5xl mx-auto">
      <CarouselContent>
        {content.map((item) => (
          <CarouselItem key={item.id}>
            <Link href={`/content/${item.id}`}>
              <Card className="relative overflow-hidden h-[400px] cursor-pointer">
                <img
                  src={item.coverUrl}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <CardContent className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 text-white">
                  <h2 className="text-3xl font-bold mb-2">{item.title}</h2>
                  <p className="text-lg opacity-90">{item.description}</p>
                </CardContent>
              </Card>
            </Link>
          </CarouselItem>
        ))}
      </CarouselContent>
      <CarouselPrevious />
      <CarouselNext />
    </Carousel>
  );
}
