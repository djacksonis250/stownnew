import { Link } from "wouter";
import { Content } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Music, Radio, Video } from "lucide-react";

const typeIcons = {
  music: Music,
  podcast: Radio,
  video: Video,
};

interface ContentGridProps {
  content: Content[];
}

export default function ContentGrid({ content }: ContentGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {content.map((item) => {
        const Icon = typeIcons[item.type];

        return (
          <Link key={item.id} href={`/content/${item.id}`}>
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <div className="relative aspect-square">
                <img
                  src={item.coverUrl}
                  alt={item.title}
                  className="w-full h-full object-cover rounded-t-lg"
                />
                <Badge className="absolute top-2 right-2">
                  <Icon className="h-4 w-4 mr-1" />
                  {item.type}
                </Badge>
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg mb-2 line-clamp-1">{item.title}</h3>
                <p className="text-muted-foreground text-sm line-clamp-2">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          </Link>
        );
      })}
    </div>
  );
}