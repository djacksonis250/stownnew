import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { type Creator } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Music, Radio, Video } from "lucide-react";

interface CreatorCardProps {
  creator: Creator;
}

export default function CreatorCard({ creator }: CreatorCardProps) {
  // Fetch creator's content to show stats
  const { data: creatorContent } = useQuery({
    queryKey: [`/api/creators/${creator.id}/content`],
  });

  // Calculate content type counts
  const contentStats = creatorContent?.reduce(
    (acc, content) => {
      acc[content.type]++;
      return acc;
    },
    { music: 0, podcast: 0, video: 0 } as Record<string, number>
  );

  return (
    <Link href={`/creator/${creator.id}`}>
      <Card className="hover:shadow-lg transition-shadow cursor-pointer overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={creator.imageUrl} alt={creator.name} />
              <AvatarFallback>
                {creator.name.split(" ").map(n => n[0]).join("")}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-semibold truncate">{creator.name}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                {creator.bio}
              </p>
            </div>
          </div>

          {contentStats && (
            <div className="flex gap-2 mt-4">
              {contentStats.music > 0 && (
                <Badge variant="secondary" className="gap-1">
                  <Music className="h-3 w-3" />
                  {contentStats.music}
                </Badge>
              )}
              {contentStats.podcast > 0 && (
                <Badge variant="secondary" className="gap-1">
                  <Radio className="h-3 w-3" />
                  {contentStats.podcast}
                </Badge>
              )}
              {contentStats.video > 0 && (
                <Badge variant="secondary" className="gap-1">
                  <Video className="h-3 w-3" />
                  {contentStats.video}
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
