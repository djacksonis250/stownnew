import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { insertCreatorSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

const SUBSCRIPTION_FEE = 200;
const LICENSING_FEE = 50; // Base fee, actual fee will be calculated based on location

interface CreatorRegistrationProps {
  defaultValues: {
    name: string;
    email: string;
    password: string;
  };
  onBack: () => void;
  onComplete: (creatorData: any) => void;
}

export default function CreatorRegistration({ defaultValues, onBack, onComplete }: CreatorRegistrationProps) {
  const [step, setStep] = useState(1);
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertCreatorSchema),
    defaultValues: {
      ...defaultValues,
      bio: "",
      imageUrl: "",
      phone: "",
      address: "",
      country: "",
      state: "",
      termsAccepted: false,
    },
  });

  const handlePayment = async (formData: any) => {
    try {
      // Initialize payment with Stripe
      toast({
        title: "Processing payment",
        description: "Please wait while we process your payment...",
      });

      // TODO: Implement Stripe payment

      onComplete(formData);
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Creator Account Setup</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handlePayment)} className="space-y-6">
            {step === 1 && (
              <>
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input {...field} type="tel" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Home Address</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State/Province</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <div className="space-y-4">
                  <div className="rounded-lg bg-muted p-4">
                    <h3 className="font-semibold mb-2">Fees Overview</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Annual Subscription Fee</span>
                        <span>${SUBSCRIPTION_FEE}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Licensing Fee</span>
                        <span>${LICENSING_FEE}</span>
                      </div>
                      <div className="border-t pt-2 font-semibold">
                        <div className="flex justify-between">
                          <span>Total</span>
                          <span>${SUBSCRIPTION_FEE + LICENSING_FEE}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <a
                      href="/creator-earnings"
                      className="text-primary hover:underline block"
                    >
                      Learn how Stown pays you
                    </a>

                    <FormField
                      control={form.control}
                      name="termsAccepted"
                      render={({ field }) => (
                        <FormItem className="flex items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              I agree to Stown's Terms & Conditions
                            </FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </>
            )}

            <CardFooter className="flex justify-between px-0">
              {step === 1 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={onBack}
                >
                  Back to Registration
                </Button>
              )}
              {step === 2 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(1)}
                >
                  Back
                </Button>
              )}
              {step === 1 ? (
                <Button
                  type="button"
                  onClick={() => setStep(2)}
                >
                  Next
                </Button>
              ) : (
                <Button
                  type="submit"
                  disabled={!form.getValues("termsAccepted")}
                >
                  Process Payment
                </Button>
              )}
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}